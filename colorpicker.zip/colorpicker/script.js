function picker() {
	let color = [];
	let val = document.getElementById("colorp").value;
	color.push(val);

	for (i = 0; i < color.length; i++) {
		let div = document.createElement("div");
		document.getElementById("body").appendChild(div);
		div.id = "firstdiv";
		div.className = "mainn";
		let sliderdiv = document.createElement("div");
		sliderdiv.id = "sliders";
		document.getElementById("body").appendChild(sliderdiv);
		sliderdiv.className = "mySlides";
		sliderdiv.style.background = color[i];

		let divv = document.createElement("a");
		k = divv.innerText = "X";
		divv.id = "hrefconnect";
		document.getElementById("firstdiv").appendChild(divv)[i];
		divv.className = "main";
		// k.onclick = function () {
		// 	document.getElementById("hrefconnect").remove();
		// }
		divv.style.background = color[i];
		divv.onclick = function () {
			currentSlide(i);
			document.getElementById("hrefconnect").remove();
			document.getElementById("sliders").remove();
		};
	}

	color = [];
}

let z = document.createElement("a");
z.innerText = "<";
z.className = "prev";
document.getElementById("body").appendChild(z);
z.onclick = function () {
	plusSlides(-1);
};

let r = document.createElement("a");
r.innerText = ">";
r.className = "next";
document.getElementById("body").appendChild(r);
r.onclick = function () {
	plusSlides(1);
};

let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
	showSlides((slideIndex += n));
}

// Thumbnail image controls
function currentSlide(n) {
	showSlides((slideIndex = n));
}

function showSlides(n) {
	var k;
	var slides = document.getElementsByClassName("mySlides");
	var dots = document.getElementsByClassName("main");

	if (n > slides.length) {
		slideIndex = 1;
	}
	if (n < 1) {
		slideIndex = slides.length;
	}
	for (k = 0; k < slides.length; k++) {
		slides[k].style.display = "none";
	}
	for (k = 0; k < dots.length; k++) {
		dots[k].className = dots[k].className.replace(" active", "");
	}

	slides[slideIndex - 1].style.display = "block";
	// dots[slideIndex - 1].className += " active";
}